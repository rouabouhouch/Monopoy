#include "sdl2jeu.h"
#include <time.h>
#include <stdlib.h>
#include <iostream>
#include <sstream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <iostream>
#include <ctime>
#include <SDL2/SDL_mixer.h>

using namespace std;

//initialise sdl | SDL_Image  | SDL_ttf | sdl_mixer----------------------------------------------------------------------
    void sdlJeu::initialisaion ()
    {
    // Initialisation de la SDL

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0)
    {
            sdl_exit_error("Erreur lors de l'initialisation de la SDL : ");
    }
    if (Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,2048)<0)
    {
        cout << "error :" <<Mix_GetError() <<endl;
    }

    if (TTF_Init() != 0)
    {
            sdl_exit_error("Erreur lors de l'initialisation de la SDL_ttf : " );

    }

    int imgFlags = IMG_INIT_PNG | IMG_INIT_JPG;
    if( !(IMG_Init(imgFlags) & imgFlags))
    {
            sdl_exit_error("Erreur lors de l'initialisation de la SDL_image : " );

    }

    // Creation de la fenetre
    window = SDL_CreateWindow
    ("THE MONOPOLY",
    SDL_WINDOWPOS_CENTERED,
    SDL_WINDOWPOS_CENTERED,screen_width,screen_height,
    SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE); //créé la fenêtre

    if (window == NULL)
    {
            sdl_exit_error("Erreur creation fenetre " );
    }

    renderer = SDL_CreateRenderer(window,-1,SDL_RENDERER_ACCELERATED);
    if (renderer == NULL)
    {
        sdl_exit_error("Erreur renderer " );

    }

    SDL_RenderPresent(renderer);


    }

   //s'occupe de creer des fentres sdl------------------------------------------------------------------------------------_
    void sdlJeu::create_window ( int mSCREEN_WIDTH, int mSCREEN_HEIGHT
                                )
    {

    mWindow = SDL_CreateWindow( "monopo", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, mSCREEN_WIDTH, mSCREEN_HEIGHT, SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE );
    if( mWindow != NULL )
    {
        mMouseFocus = true;
        mKeyboardFocus = true;


        //Create renderer for window
        mrenderer = SDL_CreateRenderer( mWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC );
        if( mrenderer == NULL )
        {
            printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
            SDL_DestroyWindow( mWindow );
            mWindow = NULL;
        }

    }
    else
    {
        printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
    }
    WindowID = SDL_GetWindowID( mWindow );
    SDL_RenderPresent(mrenderer);


    }

    // fonction de dé simple-----------------------------------------------------------------------------------------------
    void sdlJeu::sdl_dice(int & diceOne)
    {           srand(time(0));
        		diceOne = (rand() % 6) + 1;
    }

    // fonction qui dessine le dé en fonction de sa valeur --------------------------------------------------------------------------------------------
    void sdlJeu::draw_dice ()
    {

           switch (dice_test)

{
        case 1: SDL_drawing ( 0, 0 ,460,482,dice_x,dice_y , dice_width, dice_height, dice);
        break;
        case 2: SDL_drawing ( 460, 0 ,460,482,dice_x,dice_y , dice_width, dice_height, dice);
        break;
        case 3: SDL_drawing ( 920, 0 ,460,482,dice_x,dice_y , dice_width, dice_height, dice);
        break;
        case 4: SDL_drawing ( 0, 482 ,460,482,dice_x,dice_y , dice_width, dice_height, dice);
        break;
        case 5: SDL_drawing ( 460, 482 ,460,482,dice_x,dice_y , dice_width, dice_height, dice);
        break;
        case 6: SDL_drawing ( 920, 482 ,460,482,dice_x,dice_y , dice_width, dice_height, dice);
        break;

        default: printf("wrong dice number");
    }

    }

    //destructeur de la classe par defaut------------------------------------------------------------------------------
    sdlJeu::~sdlJeu ()
{
    TTF_Quit();
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
}

  // verifie les retours des fonction sdl et ferme tout en cas d'erreure--------------------------------------------------------
void sdlJeu::sdl_exit_error( const char *message)
{
    cout << message << SDL_GetError() << endl; SDL_Quit(); exit(1);

}
 //charge une texture à partir de file-name et renderer--------------------------------------------------------------------
SDL_Texture * sdlJeu::initialize_texture_from_file(const char* file_name, SDL_Renderer *renderer)
 {
    SDL_Surface *image = IMG_Load(file_name);
        if ( image == NULL)
        {
        cout <<"failed to load" << file_name;
        sdl_exit_error("failed to load picture");
        }
    SDL_Texture * image_texture = SDL_CreateTextureFromSurface(renderer, image);
    SDL_FreeSurface(image);
    return image_texture;
}
// dessine une texture sdl : si les demensions source qui sont passés en valeur nulle dessine toute la texture  sinon une partie de texture
void sdlJeu::SDL_drawing(
                            int imagex_source , int imagey_source,
                            int image_w_source, int image_h_source,
                            int imagex , int imagey ,
                            int image_width , int image_height , SDL_Texture *texture)
{
    SDL_Rect texture_destination;
    SDL_Rect texture_source;

if ((image_w_source || image_h_source) == 0 )
{
    texture_destination.x = imagex;
    texture_destination.y = imagey;
    texture_destination.w = image_width;
    texture_destination.h = image_height;
    SDL_RenderCopy(renderer, texture, NULL, &texture_destination);
}
else
    {
        //load source
    texture_source.x = imagex_source;
    texture_source.y = imagey_source;
    texture_source.w = image_w_source;
    texture_source.h = image_h_source;
        //load destination
    texture_destination.x = imagex;
    texture_destination.y = imagey;
    texture_destination.w = image_width;
    texture_destination.h = image_height;
        //copying and desplay
    SDL_RenderCopy(renderer, texture, &texture_source, &texture_destination);

}


}
// dessine le joueur sur une case
void sdlJeu::set_player (int i)
{
    if (player_1==true)
 {casesdl f =sc.get_case (i);
 positionx_joueur1=(f.x+((f.w-f.x)/2));
 positiony_joueur1=(f.y+((f.h-f.y)/2));
SDL_drawing (0,0,0,0 ,positionx_joueur1, positiony_joueur1 ,20,20,joueur1);

}
else {
casesdl f =sc.get_case (i);
positionx_joueur2=(f.x+((f.w-f.x)/2));
positiony_joueur2=(f.y+((f.h-f.y)/2));
SDL_drawing (0,0,0,0 ,positionx_joueur2, positiony_joueur2 ,20,20,joueur2);


}
}
// dessine l'hotel si le joueur achète une case----------------------------------------------------------------
void sdlJeu::fill_hotel_position(hotel tab[40],int x,int y ,int w,int &m ,int &check)
{
      tab[m].pos_x=x;
      tab[m].pos_y=y;
      tab[m].num=w;
        m=m+1;
        check=1;

}
// version qui dessine sur la fenetre pop-up-------------------------------------------------------------------------
void sdlJeu::SDL_drawing2(int imagex_source , int imagey_source,
                        int image_w_source, int image_h_source,
                        int imagex , int imagey ,
                        int image_width , int image_height , SDL_Texture *texture,int x)
                        {

                        SDL_Rect texture_destination;
                        SDL_Rect texture_source;

                        if ((image_w_source || image_h_source) == 0 )
                        {
                        texture_destination.x = imagex;
                        texture_destination.y = imagey;
                        texture_destination.w = image_width;
                        texture_destination.h = image_height;
                        SDL_RenderCopy(mrenderer, texture, NULL, &texture_destination);
}
    else
                        {
                            //load source
                        texture_source.x = imagex_source;
                        texture_source.y = imagey_source;
                        texture_source.w = image_w_source;
                        texture_source.h = image_h_source;
                            //load destination
                        texture_destination.x = imagex;
                        texture_destination.y = imagey;
                        texture_destination.w = image_width;
                        texture_destination.h = image_height;
                            //copying and desplay
                        SDL_RenderCopy(mrenderer, texture, &texture_source, &texture_destination);
                        }
                        }
// bouge les joueur en fonction de dé-----------------------------------------------------------------------------
void sdlJeu::move_player(int &case_test)
{

case_test=case_test+dice_test;
switch(case_test)
 {
 case 1: set_player(0);
 break;
 case 2: set_player(1);
 break;
 case 3: set_player(2);
 break;
 case 4: set_player(3);
 break;
 case 5: set_player(4);
 break;
 case 6: set_player(5);
 break;
 case 7: set_player(6);
 break;
 case 8: set_player(7);
 break;
 case 9: set_player(8);
 break;
 case 10: set_player(9);
 break;
 case 11: set_player(10);
 break;
 case 12: set_player(11);
 break;
 case 13: set_player(12);
 break;
 case 14: set_player(13);
 break;
 case 15: set_player(14);
 break;
 case 16: set_player(15);
 break;
 case 17: set_player(16);
 break;
 case 18: set_player(17);
 break;
 case 19: set_player(18);
 break;
 case 20: set_player(19);
 break;
 case 21: set_player(20);
 break;
 case 22: set_player(21);
 break;
 case 23: set_player(22);
 break;
 case 24: set_player(23);
 break;
 case 25: set_player(24);
 break;
 case 26: set_player(25);
 break;
 case 27: set_player(26);
 break;
 case 28: set_player(27);
 break;
 case 30: set_player(29);
 break;
 case 31: set_player(30);
 break;
 case 32: set_player(31);
 break;
 case 33: set_player(32);
 break;
 case 34: set_player(33);
 break;
 case 35: set_player(34);
 break;
 case 36: set_player(35);
 break;
 case 37: set_player(36);
 break;
 case 38: set_player(37);
 break;
 case 39: set_player(38);
 break;
 case 40: set_player(39);
 break;
 default: if (case_test>40)
    {case_test=case_test-40;}
    set_player(case_test-1);
    if (case_test > 40 or case_test<1)
    {cout << "error access denied case number  "<< case_test <<endl;}


 }
}

//boucle principale----------------------------------------------------------------------------------------------
void sdlJeu::sdl_boucle()
{   bool running0=true;
    Mix_Music *bgm=Mix_LoadMUS("bgm.mp3");
    Mix_Chunk *soundeffect=Mix_LoadWAV("effect.wav");
    Mix_Chunk *soundeffect2=Mix_LoadWAV("effect2.wav");


    if(!Mix_PlayingMusic())
    Mix_PlayMusic(bgm,-1);
    else if (Mix_PausedMusic())
    Mix_ResumeMusic();

    while (running0)
    {
         while(SDL_PollEvent(&event))
         {

              if(event.type == SDL_KEYDOWN)
                    {
                    Mix_PlayChannel(-1,soundeffect,0);
                    Mix_HaltMusic();
                    running0= false;
                    }

         }




                    for(int i=0;i<=30;i++)
                    {
                    SDL_drawing ( 0, 0 ,0,0,0,i ,screen_width +200, screen_height , start);
                    SDL_RenderPresent(renderer);
                    SDL_Delay(30);
                    }
                    for(int i=30;i>=0;i--)
                    {
                    SDL_drawing ( 0, 0 ,0,0,0,i ,screen_width +200, screen_height , start);
                    SDL_RenderPresent(renderer);
                    SDL_Delay(5);
                    }


    }


    SDL_StartTextInput();
    bool running = true;
    while(running)
    {   //The rerender text flag
        // Process events
        while(SDL_PollEvent(&event))
        {
                 if(event.type == SDL_QUIT)
                    {
                    running = false;
                    }

             else if (mWindow!=NULL) {
                     SDL_ShowWindow(mWindow);
                    if(event.type ==  SDL_WINDOWEVENT && SDL_GetWindowID(mWindow) == event.window.windowID)

                    {
                        if (event.window.event == SDL_WINDOWEVENT_CLOSE )
                            {  SDL_ShowWindow( window );
                                SDL_RaiseWindow( window );
                                SDL_DestroyWindow(mWindow);
                                mWindow=NULL;
                             }
                    }
                      if (event.type==SDL_MOUSEBUTTONDOWN)
                       {   if (case_achetable==true)
                           { if ((event.button.x>=yes_x && event.button.x <=yes_x+yes_w) &&
                        (event.button.y>=yes_y && event.button.y <=yes_y+yes_h) )
                        {
                              SDL_ShowWindow( window );
                              SDL_RaiseWindow( window );
                              SDL_DestroyWindow(mWindow);
                              mWindow=NULL;
                              if (player_1==false)
                              {  if (p1.money>sc.get_case(case_joueur1-1).price)
                                {acheter_joueur1=true;
                                cout <<p1.name << " achète cette case " <<endl;
                                sc.set_possederpar(1,case_joueur1-1);
                                cout <<sc.get_case(case_joueur1-1).posseder_par_joueur;
                                p1.money=p1.money-sc.get_case(case_joueur1-1).price;
                                money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);
                                case_achetable=false;
                                }
                                else{ cout <<"impossible d'acheter la case avec votre argent" <<endl;


    }


                              }
                              if (player_1==true)
                              {   if (p2.money>sc.get_case(case_joueur2-1).price)
                                  {
                                  acheter_joueur2=true;
                                 cout <<p2.name << " achète cette case " <<endl;

                                  sc.set_possederpar(2,case_joueur2-1);
                                  cout <<sc.get_case(case_joueur2-1).posseder_par_joueur <<endl;
                                  p2.money=p2.money-sc.get_case(case_joueur2-1).price;
                                  money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw1,moneyh1);
                                  case_achetable=false;
                                  }

                                      else{cout <<"impossible d'acheter la case avec votre argent" <<endl;}



                              }
                        }

                        else if ((event.button.x>=yes_x+yes_w && event.button.x <=yes_x+(2*yes_w) &&
                        (event.button.y>=yes_y && event.button.y <=yes_y+yes_h) ))
                        {
                            SDL_ShowWindow( window );
                              SDL_RaiseWindow( window );
                              SDL_DestroyWindow(mWindow);
                              mWindow=NULL;

                        }

                           }
                       }

                    }
          else if (event.type==SDL_MOUSEBUTTONDOWN)
                {   if  ((event.button.x>=dice_x && event.button.x <=dice_x+dice_width) &&
                        (event.button.y>=dice_y && event.button.y <=dice_y+dice_height) )
                        {
                                Mix_PlayChannel(-1,soundeffect2,0);

                                sdl_dice(dice_test);
                                draw_dice();
                                create_window(screen_width2,screen_height2);
                                SDL_ShowWindow( mWindow );
                                SDL_RaiseWindow( mWindow );
                                if (player_1==true)
                                {
                                if (sent_to_jail==true)
                                {
                                    player_1=false;
                                    cout<<p1.name << "ne peut pas bouger car en prison";
                                    background2=initialize_texture_from_file("injail.jpg",mrenderer);
                                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                                    SDL_RenderPresent(mrenderer);

                                    sent_to_jail=false;
                                }
                                else{
                                cout<< "player 1 turn" <<endl;
                                move_player( case_joueur1);
                                create_popup_window(sc.get_case(case_joueur1-1).case_type, case_joueur1-1);
                                player_1=(!player_1);
                                }
                                }
                                else
                                {
                                   if (sent_to_jail2==true)
                                {
                                    cout<<p1.name << "ne peut pas bouger car en prison";
                                    background2=initialize_texture_from_file("injail.jpg",mrenderer);
                                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                                    SDL_RenderPresent(mrenderer);
                                    player_1=true;
                                    cout<<p2.name << "ne peut pas bouger car en prison"<<endl;
                                    sent_to_jail2=false;
                                }
                                else
                                {
                                    cout <<"player 2 turn" <<endl;
                                    move_player (case_joueur2);
                                    create_popup_window(sc.get_case(case_joueur2-1).case_type, case_joueur2-1);

                                    player_1=(!player_1);
                                }
                                }
                                SDL_RenderPresent(renderer);



                        }
            }

                else if (event.type==SDL_MOUSEMOTION)
                {
                    //cout << "x = " <<event.motion.x <<" y = " << event.motion.y  <<endl;
                }
            else
                {

                if (type_player1==true)
            {   rendertext1=true;

                handle_input(p1.name,rendertext1);
                if (keystates [SDL_SCANCODE_DOWN])
                {
                    type_player1=false;
                }
            }
                if (type_player1==false)
                {
                rendertext2=true;
                handle_input(p2.name,rendertext2);
                if (keystates [SDL_SCANCODE_UP])
                {
                    type_player1=true;
                }
                }
            }

        }
        SDL_RenderClear(renderer);
        if (rendertext1==true)
        {player1name=load_input(p1.name,rendertext1,texW,texH);}
        else if (rendertext2==true)
        {player2name=load_input(p2.name,rendertext2,texW2,texH2);}
        SDL_QueryTexture(player1name, NULL, NULL, &texW, &texH);
        SDL_QueryTexture(player2name, NULL, NULL, &texW2, &texH2);
        SDL_QueryTexture(money1, NULL, NULL, &moneyw1, &moneyh1);
        SDL_QueryTexture(money2, NULL, NULL, &moneyw2, &moneyh2);




        SDL_drawing ( 0, 0 ,0,0,0,0 ,screen_width , screen_height , Background);
        SDL_drawing ( 0, 0 ,0,0,0,0 ,screen_width , screen_height , plateau);
        SDL_drawing(0,0,0,0, (screen_width/2)-120 ,(screen_height/2-200)-20 , 300, 300 ,monopolyguy);
        SDL_drawing(0,0,0,0, (screen_width/2)-300 ,(screen_height/2-200) , 100, 100 ,player1);
        SDL_drawing(0,0,0,0, (screen_width/2)-300 ,(screen_height/2)-40 , moneyw1, moneyh1 ,money1);
        SDL_drawing(0,0,0,0, (screen_width/2)+230 ,(screen_height/2)-40 , moneyw2, moneyh2 ,money2);

        SDL_drawing(0,0,0,0, (screen_width/2)+230 ,(screen_height/2-200) , 100, 100 ,player2);
        SDL_drawing (0,0,0,0 ,positionx_joueur1, positiony_joueur1 ,20,20,joueur1);
        SDL_drawing (0,0,0,0 ,positionx_joueur2 , positiony_joueur2,20,20,joueur2);
        SDL_drawing (0,0,0,0 ,(screen_width/2)-300 , (screen_height/2-200)+100,texW,texH,player1name);
        SDL_drawing (0,0,0,0 ,(screen_width/2)+210 ,(screen_height/2-200)+100,texW2,texH2,player2name);
        if (player_1==true)
        {
        SDL_drawing(0,0,0,0, (screen_width/2)-340 ,(screen_height/2), 200, 200 ,turn);
        }
        else
        {
        SDL_drawing(0,0,0,0, (screen_width/2)+190 ,(screen_height/2), 200, 200 ,turn);

        }

        if (acheter_joueur1==true)
        {
        fill_hotel_position(red,sc.get_case(case_joueur1-1).x,sc.get_case(case_joueur1-1).y,case_joueur1-1,i,a);
        }
        if (acheter_joueur2==true)
        {
        fill_hotel_position(green,sc.get_case(case_joueur2-1).x,sc.get_case(case_joueur2-1).y,case_joueur2-1,z,b);
        }
        if (a==1)
        {
        for(int m=0; m<i;m++)
        {SDL_drawing ( 0, 0 ,0,0,red[m].pos_x ,red[m].pos_y , 25, 25 , redhotel[red[m].num]);
        acheter_joueur1=false;}
        }
            if (b==1)
        { for(int m=0; m<z;m++)
         SDL_drawing ( 0, 0 ,0,0,green[m].pos_x ,green[m].pos_y , 25, 25 , greenhotel[green[m].num]);
        acheter_joueur2=false;
        }






        draw_dice();
        SDL_RenderPresent(renderer);
        if(p1.money<=0)
        {   SDL_Delay(1000);
            SDL_DestroyWindow(mWindow);
            running=false;
            player2_wins=true;

        }
        if (p2.money<=0)
        {   SDL_Delay(1000);
            SDL_DestroyWindow(mWindow);
            SDL_Delay(1000);
            running=false;
            player1_wins=true;
        }



    }

    bool running3=true;
    Mix_Chunk *soundeffect3=Mix_LoadWAV("victory.wav");


    while (running3)
    {
        while(SDL_PollEvent(&event))
        {
     if(event.type == SDL_QUIT)
                    {
                    running3 = false;
                    }
      else if (event.type==SDL_KEYDOWN)
      {
           Mix_PlayChannel(-1,soundeffect3,0);
      }
        }


        SDL_RenderClear(renderer);
        if(player1_wins==true)
        {
            font=TTF_OpenFont("test.ttf", 100);
            player_win=create_text_texture((p1.name +" won the game ").c_str(),Red,win_w,win_h);
            player1_wins=false;
        }
        else if (player2_wins==true)
        {
            font=TTF_OpenFont("test.ttf", 100);

            player_win=create_text_texture((p2.name +" won the game ").c_str(),Green,win_w,win_h);
            player2_wins=false;
        }


        SDL_QueryTexture(player_win, NULL, NULL, &win_w, &win_h);
        for (int i=screen_height/3 ; i<(screen_height/3)+30 ;i++   )
        {
        SDL_RenderClear(renderer);
        SDL_drawing ( 0, 0 ,0,0,0,0 ,screen_width+200 , screen_height , victory);
        SDL_drawing ( 0, 0 ,0,0,100,i ,win_w, win_h , player_win);
        SDL_RenderPresent(renderer);
        SDL_Delay(10);
        }






    }


    // Release resources
    IMG_Quit();
    SDL_DestroyRenderer(renderer);
    SDL_DestroyTexture(plateau);
    SDL_DestroyTexture(dice);
    SDL_DestroyTexture(player1);
    SDL_DestroyTexture(player2);
    SDL_DestroyTexture(joueur1);
    SDL_DestroyTexture(joueur2);
    SDL_DestroyTexture(Background);
    SDL_DestroyTexture(monopolyguy);
    SDL_DestroyTexture(mytexture);
    SDL_DestroyTexture(player1name);
    SDL_DestroyTexture(player2name);
    SDL_DestroyTexture(message_window2);
    SDL_DestroyTexture(yes);

    SDL_DestroyWindow(window);
    Mix_FreeMusic(bgm);
    Mix_Quit();
    SDL_Quit();

}

// gestionaire de jeu sdl qui charge texture et commence la boucle -------------------------------------------------------
void sdlJeu::sdl_jouer()
{
    p1.name="player1";
    p2.name="player2";
    p1.money=500;
    p2.money=500;
    initialisaion();
    font=TTF_OpenFont("test.ttf", 40);
    font2=TTF_OpenFont("police.ttf", 20);
    if(!font) {printf("TTF_OpenFont: %s\n", TTF_GetError());}
    sdl_dice(dice_test);
    for (int i=0;i<40;i++)
    {redhotel[i]=initialize_texture_from_file("hotelrouge.png",renderer);
     greenhotel[i]=initialize_texture_from_file("hotelvert.png",renderer);
    }
    plateau= initialize_texture_from_file("monopoly.png", renderer);
    start=initialize_texture_from_file("start.jpg", renderer);
    turn=initialize_texture_from_file("turn.png", renderer);

    monopolyguy= initialize_texture_from_file("monopolyguy.png", renderer);
    dice= initialize_texture_from_file("dice.png", renderer);
    player1= initialize_texture_from_file("player1.png", renderer);
    player2=initialize_texture_from_file("player2.png" ,renderer);
    joueur1=initialize_texture_from_file("joueur1.png" ,renderer);
    joueur2=initialize_texture_from_file("joueur2.png" ,renderer);
    Background=initialize_texture_from_file("background.jpg" ,renderer);
    victory=initialize_texture_from_file("victory.jpg",renderer);
    player1name=create_text_texture( p1.name.c_str(), black ,texW,texH);
    player2name=create_text_texture(p2.name.c_str(),black,texW2,texH2);
    money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);
    money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw2,moneyh2);
    SDL_QueryTexture(money1, NULL, NULL, &moneyw1, &moneyh1);
    SDL_QueryTexture(money2, NULL, NULL, &moneyw2, &moneyh2);




    sdl_boucle ();
}

//creer texture de TEXTE pour la fenetre principale ---------------------------------------------------------------
  SDL_Texture * sdlJeu::create_text_texture (const char *text ,SDL_Color textColor,int & textw_text ,int & texth_text)
    {

    textsurface = TTF_RenderText_Solid( font, text, textColor );
    if( textsurface == NULL )
    {
        printf( "Unable to render text surface! SDL_ttf Error: %s\n", TTF_GetError() );
    }
    else
    {
        //Create texture from surface pixels
        mytexture = SDL_CreateTextureFromSurface( renderer, textsurface );
        if( mytexture == NULL )
        {
            printf( "Unable to create texture from rendered text! SDL Error: %s\n", SDL_GetError() );
        }
    }
            SDL_FreeSurface( textsurface );


            return mytexture ;

    }
  //creeer texture de TEXTRE pour les pop ups -------------------------------------------------------------------------
  SDL_Texture * sdlJeu::create_text_texture2 (const char *text ,SDL_Color textColor,int & textw_text ,int & texth_text)
    {

    textsurface = TTF_RenderText_Solid( font2, text, textColor );
    if( textsurface == NULL )
    {
        printf( "Unable to render text surface! SDL_ttf Error: %s\n", TTF_GetError() );
    }
    else
    {
        //Create texture from surface pixels
        mytexture = SDL_CreateTextureFromSurface( mrenderer, textsurface );
        if( mytexture == NULL )
        {
            printf( "Unable to create texture from rendered text! SDL Error: %s\n", SDL_GetError() );
        }
    }
            SDL_FreeSurface( textsurface );


            return mytexture ;

    }
   // s'occupe du clavier : va charger un string en fonction de ce que l'utilisateur tape dans la fenetre sdl------------------
    void sdlJeu::handle_input(std::string &character_name ,bool &renderText)
        {

                if( keystates[SDL_SCANCODE_BACKSPACE] && character_name.length() > 0 )
                        {
                            character_name.pop_back();
                            cout <<character_name <<endl;

                            renderText=true;


                        }
                        //Handle copy
                else if( event.key.keysym.sym == SDLK_c && SDL_GetModState() & KMOD_CTRL )
                        {


                        }
                        //Handle paste
                 else if( event.key.keysym.sym == SDLK_v && SDL_GetModState() & KMOD_CTRL )
                        {

                        }

                 else if (event.type==SDL_TEXTINPUT)
                        {   if (character_name.length()<6)
                            {
                            character_name += event.text.text;
                            renderText=true;
                            cout <<character_name <<endl;
                            }


                        }
        }

     // charge le string fournis par la fonction handle_input ()-------------------------------------------------------
    SDL_Texture *sdlJeu::load_input(std::string & player_name , bool &input , int x1 ,int x2)
    {   SDL_Texture *texture_;

            if( input==true )
                {
                        if( player_name== "" )
                        {
                         texture_=create_text_texture( " . ", black ,texW,texH);

                        }
                        else if (player_name!="")
                        {
                        texture_=create_text_texture( player_name.c_str(), black ,x1,x2);

                        }

                }
                    input=false;
                    return texture_;
                }
    // s'occupe de creer des pop-up windows et leurs affichage en fonction de case joueur;------------------------------------
    void sdlJeu::create_popup_window(int type_case, int num_case)
    {
          int  posseder= sc.get_case(num_case).posseder_par_joueur;
          cout <<"posseder =" <<posseder <<endl;
          cout <<"type case = " <<type_case <<endl;
            switch (type_case)
            {
            case 1:
            if (posseder==NULL)
            { case_achetable=true;
            window_message= "voulez vous acheter "+sc.get_case(num_case).nom_case+" ? ";

            background2=initialize_texture_from_file("background.jpg",mrenderer);
            yes= initialize_texture_from_file("yes.png",mrenderer);
            message_window2=create_text_texture2(window_message.c_str(),black,messagew,messageh);

            SDL_QueryTexture(message_window2, NULL, NULL, &messagew, &messageh);

            SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
            SDL_drawing2 ( 0, 0 ,960/2,480,(screen_width2/3)-20,screen_height2/3 ,100, 100 , yes ,0);
            SDL_drawing2 ( 960/2, 0 ,960/2,480,(screen_width2/2)+20,screen_height2/3 ,100, 100 , yes ,0);

            SDL_drawing2 ( 0, 0 ,0,0,((screen_width2/2)-(screen_width2/3)),0 ,messagew , messageh , message_window2,0);

            SDL_RenderPresent(mrenderer);
            }
            else if (posseder==1)
            {
                if (player_1==true)
                {
                    window_message=sc.get_case(num_case).nom_case+ " posseder par " +p1.name;
                    background2=initialize_texture_from_file("background.jpg",mrenderer);
                    message_window2=create_text_texture2(window_message.c_str(),black,messagew,messageh);
                    SDL_QueryTexture(message_window2, NULL, NULL, &messagew, &messageh);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_drawing2 ( 0, 0 ,0,0,((screen_width2/2)-(screen_width2/3)),0 ,messagew , messageh , message_window2,0);
                    SDL_RenderPresent(mrenderer);

                }
                else if (player_1==false)
                {
                    window_message="vous payez un loyer " + to_string(sc.get_case(num_case).price)+ " Euros";
                    background2=initialize_texture_from_file("background.jpg",mrenderer);
                    message_window2=create_text_texture2(window_message.c_str(),black,messagew,messageh);
                    SDL_QueryTexture(message_window2, NULL, NULL, &messagew, &messageh);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_drawing2 ( 0, 0 ,0,0,((screen_width2/2)-(screen_width2/3)),0 ,messagew , messageh , message_window2,0);
                    SDL_RenderPresent(mrenderer);

                    p2.money=p2.money-sc.get_case(num_case).price;
                    if (p2.money >0)
                    {
                      money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw2,moneyh2);
                    }
                    else
                    {
                      money2=create_text_texture( "0", black ,moneyw2,moneyh2);
                    };

                }

            }
            else if (posseder==2)
            {

                  if (player_1==false)
                  {

                    window_message=sc.get_case(num_case).nom_case+ " posseder par " +p2.name;
                    background2=initialize_texture_from_file("background.jpg",mrenderer);
                    message_window2=create_text_texture2(window_message.c_str(),black,messagew,messageh);
                    SDL_QueryTexture(message_window2, NULL, NULL, &messagew, &messageh);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_drawing2 ( 0, 0 ,0,0,((screen_width2/2)-(screen_width2/3)),0 ,messagew , messageh , message_window2,0);
                    SDL_RenderPresent(mrenderer);


                  }
                         else if (player_1==true)
                {
                    window_message="vous payez " + to_string(sc.get_case(num_case).price)+ " Euros";
                    background2=initialize_texture_from_file("background.jpg",mrenderer);
                    message_window2=create_text_texture2(window_message.c_str(),black,messagew,messageh);
                    SDL_QueryTexture(message_window2, NULL, NULL, &messagew, &messageh);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_drawing2 ( 0, 0 ,0,0,((screen_width2/2)-(screen_width2/3)),0 ,messagew , messageh , message_window2,0);
                    SDL_RenderPresent(mrenderer);
                    p1.money=p1.money-sc.get_case(num_case).price;
                    if (p1.money>0)
                    {money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);}
                    else
                    {money1=create_text_texture( "0", black ,moneyw1,moneyh1);}



                }


            }
            case 2:
            if (posseder==NULL)
            { case_achetable=true;
            window_message= "voulez vous acheter "+sc.get_case(num_case).nom_case+" ? ";

            background2=initialize_texture_from_file("background.jpg",mrenderer);
            yes= initialize_texture_from_file("yes.png",mrenderer);
            message_window2=create_text_texture2(window_message.c_str(),black,messagew,messageh);

            SDL_QueryTexture(message_window2, NULL, NULL, &messagew, &messageh);

            SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
            SDL_drawing2 ( 0, 0 ,960/2,480,(screen_width2/3)-20,screen_height2/3 ,100, 100 , yes ,0);
            SDL_drawing2 ( 960/2, 0 ,960/2,480,(screen_width2/2)+20,screen_height2/3 ,100, 100 , yes ,0);

            SDL_drawing2 ( 0, 0 ,0,0,((screen_width2/2)-(screen_width2/3)),0 ,messagew , messageh , message_window2,0);

            SDL_RenderPresent(mrenderer);
            }
            else if (posseder==1)
            {
                if (player_1==true)
                {
                    window_message=sc.get_case(num_case).nom_case+ " posseder par " +p1.name;
                    background2=initialize_texture_from_file("background.jpg",mrenderer);
                    message_window2=create_text_texture2(window_message.c_str(),black,messagew,messageh);
                    SDL_QueryTexture(message_window2, NULL, NULL, &messagew, &messageh);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_drawing2 ( 0, 0 ,0,0,((screen_width2/2)-(screen_width2/3)),0 ,messagew , messageh , message_window2,0);
                    SDL_RenderPresent(mrenderer);

                }
                else if (player_1==false)
                {
                    window_message="vous payez loyer" + to_string(sc.get_case(num_case).price)+ " Euros";
                    background2=initialize_texture_from_file("background.jpg",mrenderer);
                    message_window2=create_text_texture2(window_message.c_str(),black,messagew,messageh);
                    SDL_QueryTexture(message_window2, NULL, NULL, &messagew, &messageh);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_drawing2 ( 0, 0 ,0,0,((screen_width2/2)-(screen_width2/3)),0 ,messagew , messageh , message_window2,0);
                    SDL_RenderPresent(mrenderer);

                    p2.money=p2.money-sc.get_case(num_case).price;
                    if (p2.money >0)
                    {
                      money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw2,moneyh2);
                    }
                    else
                    {
                      money2=create_text_texture( "0", black ,moneyw2,moneyh2);
                    };

                }

            }
            else if (posseder==2)
            {

                  if (player_1==false)
                  {

                    window_message=sc.get_case(num_case).nom_case+ " posseder par " +p2.name;
                    background2=initialize_texture_from_file("background.jpg",mrenderer);
                    message_window2=create_text_texture2(window_message.c_str(),black,messagew,messageh);
                    SDL_QueryTexture(message_window2, NULL, NULL, &messagew, &messageh);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_drawing2 ( 0, 0 ,0,0,((screen_width2/2)-(screen_width2/3)),0 ,messagew , messageh , message_window2,0);
                    SDL_RenderPresent(mrenderer);


                  }
                         else if (player_1==true)
                {
                    window_message="vous payez " + to_string(sc.get_case(num_case).price)+ " Euros";
                    background2=initialize_texture_from_file("background.jpg",mrenderer);
                    message_window2=create_text_texture2(window_message.c_str(),black,messagew,messageh);
                    SDL_QueryTexture(message_window2, NULL, NULL, &messagew, &messageh);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_drawing2 ( 0, 0 ,0,0,((screen_width2/2)-(screen_width2/3)),0 ,messagew , messageh , message_window2,0);
                    SDL_RenderPresent(mrenderer);
                    p1.money=p1.money-sc.get_case(num_case).price;
                    if (p1.money>0)
                    {money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);}
                    else
                    {money1=create_text_texture( "0", black ,moneyw1,moneyh1);}

                }


                }
                break;

                 case 3:
                {sdl_dice(dice2);
                switch(dice2)
                {
                    case 1:
                    background2=initialize_texture_from_file("chance1.png",mrenderer);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_RenderPresent(mrenderer);
                    set_player(0);

                    if (player_1==true)
                        {   case_joueur1=1;
                            p1.money=p1.money+200;
                            money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);

                        }
                    else
                        {   case_joueur2=1;
                            p2.money=p2.money+200;
                            money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw2,moneyh2);

                        }
                    SDL_RenderPresent(renderer);
                    break;
                    case 2:
                    background2=initialize_texture_from_file("chance2.png",mrenderer);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_RenderPresent(mrenderer);
                             if (player_1==true)
                        {
                            p1.money=p1.money+50;
                            money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);

                        }
                    else
                        {
                            p2.money=p2.money+50;
                            money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw2,moneyh2);

                        }
                    break;
                    case 3:
                    background2=initialize_texture_from_file("chance3.png",mrenderer);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_RenderPresent(mrenderer);
                             if (player_1==true)
                        {
                            p1.money=p1.money+15;
                            money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);

                        }
                    else
                        {
                            p2.money=p2.money+15;
                            money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw2,moneyh2);

                        }
                    break;
                    case 4:
                    background2=initialize_texture_from_file("chance4.png",mrenderer);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_RenderPresent(mrenderer);
                             if (player_1==true)
                        {
                            p1.money=p1.money+15;
                            money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);

                        }
                    else
                        {
                            p2.money=p2.money+15;
                            money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw2,moneyh2);
                        }
                    break;
                    case 5:
                    background2=initialize_texture_from_file("chance5.png",mrenderer);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_RenderPresent(mrenderer);
                    set_player(29);
                    if (player_1==true)
                    {
                        case_joueur1=30;
                    }
                    else
                    {
                        case_joueur2=30;
                    }
                    SDL_RenderPresent(renderer);

                    break;
                    case 6:
                    background2=initialize_texture_from_file("chance6.png",mrenderer);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_RenderPresent(mrenderer);
                                           if (player_1==true)
                        {
                            p1.money=p1.money+100;
                            money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);

                        }
                    else
                        {
                            p2.money=p2.money+100;
                            money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw2,moneyh2);
                    }
                    break;

                }
                } break;
                    case 4:
                    background2=initialize_texture_from_file("jail.jpg",mrenderer);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_RenderPresent(mrenderer);
                    set_player(10);
                    if (player_1==true){case_joueur1=11;sent_to_jail=true;} else {case_joueur2=11; sent_to_jail2=true;}
                    SDL_RenderPresent(renderer);

                    break;
                    case 5:
                    background2=initialize_texture_from_file("jail_visit.jpg",mrenderer);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_RenderPresent(mrenderer);
                    break;
                    case 6:
                    sdl_dice(dice2);
                    switch (dice2)
                    {
                    case 1:
                    background2=initialize_texture_from_file("community0.png",mrenderer);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_RenderPresent(mrenderer);
                    set_player(0);
                    if (player_1==true)
                        {   case_joueur1=1;
                            p1.money=p1.money+200;
                            money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);

                        }
                    else
                        {   case_joueur2=1;
                            p2.money=p2.money+200;
                            money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw2,moneyh2);

                        }
                      SDL_RenderPresent(renderer);
                      break;
                      case 2:
                            background2=initialize_texture_from_file("community1.png",mrenderer);
                            SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                            SDL_RenderPresent(mrenderer);
                            if (player_1==true)
                        {
                            p1.money=p1.money+75;
                            money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);

                        }
                    else
                        {
                            p2.money=p2.money+75;
                            money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw2,moneyh2);

                        }

                        break;
                      case 3:
                            background2=initialize_texture_from_file("community2.png",mrenderer);
                            SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                            SDL_RenderPresent(mrenderer);
                            if (player_1==true)
                        {
                            p1.money=p1.money+150;
                            money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);

                        }
                    else
                        {
                            p2.money=p2.money+150;
                            money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw2,moneyh2);

                        }
                        break;
                      case 4:
                            background2=initialize_texture_from_file("community3.png",mrenderer);
                            SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                            SDL_RenderPresent(mrenderer);
                            set_player(32);
                            if (player_1==true){case_joueur1=33;} else{case_joueur2=33;}
                            SDL_RenderPresent(renderer);

                        break;
                      case 5:
                            background2=initialize_texture_from_file("community4.png",mrenderer);
                            SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                            SDL_RenderPresent(mrenderer);
                            if (player_1==true)
                        {
                            p1.money=p1.money+100;
                            money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);

                        }
                    else
                        {
                            p2.money=p2.money+100;
                            money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw2,moneyh2);

                        }
                        break;
                      case 6:
                            background2=initialize_texture_from_file("community5.png",mrenderer);
                            SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                            SDL_RenderPresent(mrenderer);
                       if (player_1==true)
                        {
                            p1.money=p1.money+20;
                            money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);

                        }
                    else
                        {
                            p2.money=p2.money+20;
                            money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw2,moneyh2);

                        }
                        break;

                    }
                    break;
        case 7:
                    window_message="vous payez une Facture de " + to_string(sc.get_case(num_case).price)+ " Euros";
                    background2=initialize_texture_from_file("background.jpg",mrenderer);
                    message_window2=create_text_texture2(window_message.c_str(),black,messagew,messageh);
                    SDL_QueryTexture(message_window2, NULL, NULL, &messagew, &messageh);
                    SDL_drawing2 ( 0, 0 ,0,0,0,0 ,screen_width2 , screen_height2 , background2,0);
                    SDL_drawing2 ( 0, 0 ,0,0,((screen_width2/2)-(screen_width2/3)),0 ,messagew , messageh , message_window2,0);
                    SDL_RenderPresent(mrenderer);
                    if (player_1==false)
                    {
                    p2.money=p2.money-sc.get_case(num_case).price;
                    if (p2.money >0)
                    {
                      money2=create_text_texture( to_string(p2.money).c_str(), black ,moneyw2,moneyh2);
                    }
                    else
                    {
                      money2=create_text_texture( "0", black ,moneyw2,moneyh2);
                    }

                    }
                    else
                    {
                    p1.money=p1.money-sc.get_case(num_case).price;
                    if (p1.money >0)
                    {
                      money1=create_text_texture( to_string(p1.money).c_str(), black ,moneyw1,moneyh1);
                    }
                    else
                    {
                      money1=create_text_texture( "0", black ,moneyw1,moneyh1);
                    }
                    }




    }
    // end cases

    }
