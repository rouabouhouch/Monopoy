#include "Case.h"
#include "Joueur.h"

Case::Case(int position, string nom, int type, int prix, int loy) {
    typeCase= type;
    prixCase = prix;
    loyer = loyer;
    possederPar=NULL;
    nomC = nom;
    positionDansPlateau=position;
}
Case::~Case() {}

string Case::getNomC() {
    return nomC;
}

int Case::getTypeCase() {
    return typeCase;
}

int Case::getPrix() {
    return prixCase;
}

int Case::getLoyer() {
    return loyer;
}

Joueur* Case::getPossederPar() {
    return possederPar;
}

int Case::getPositionDansPlateau() {
    return positionDansPlateau;
}

void Case::setPossederPar(Joueur* j) {
    possederPar = j;
}
