#include<iostream>
#include<cstring>
#include <vector>
#include<string>
#include "Joueur.h"
#include "Case.h"

//////////get functions
 Joueur::Joueur(string nom,Case* depart){
	 nomJ=nom;
	joueurPosition=depart;

	 //gamePieceName="Hat";
	 argent=10000;
	}

 Joueur::Joueur(Case* depart){
	nomJ= "John";
	joueurPosition=depart;
	argent=10000;
}

 string Joueur::getNom(){
	return nomJ;
}
int Joueur::getArgent() {
    return argent;
}

Case* Joueur::getJoueurPosition(){
       return joueurPosition;
}
string Joueur::getCassePossede() {
    //return casePosseder;
}
///////set functions

void Joueur::setCasePossede(Case* cas){
	//casePosseder.push_back(cas);
    //casePosseder.pop_back(cas);
}


void Joueur::setJoueurPosition(Case* cas1){
	 joueurPosition=cas1;
}

 void Joueur::setArgent(int arg){
	 argent=arg;
 }

void Joueur::giveMoney(int amount){
	argent=argent+amount;
}

void Joueur::takeMoney(int amount){
	 argent=argent-amount;
 }

 //the functions we may need

 /*void Player::movePlayer(int number){
	Location=Location+number;
}

void Player::setGamePieceName(string inputPieceName){
	gamePieceName=inputPieceName;
}
*/
