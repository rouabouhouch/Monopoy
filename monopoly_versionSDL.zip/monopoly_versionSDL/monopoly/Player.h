

#ifndef PLAYER_H_
#define PLAYER_H_
#include <string>

using namespace std;

struct Coordinates{
	int x;
	int y;
};

class Player {
private:
	string gamePieceName;
	string playerName;
	int Location;
	int moneyAmount;
	Coordinates pixelLocation;

public:
	//constructors
	Player();
	Player(money);

	//functions to set
	void setPalyerName(string inputName);
	void setGamePieceName(string inputPieceName);
	void setLocation(int inputSpace);
	void setmoneyAmount(int inputNum);
	void setPixelLocation(Coordinates location);

	//functions to get
	string getPlayerName();
	string getgamePieceName;
	int getLocation;
	int moneyAmount;
	Coordinates getpixelLocation();

	//money functions
	void giveMoney(int amount);
	void takeMoney(int amount);
    void movePlayer();
    void reset();






	Player();

};

#endif
