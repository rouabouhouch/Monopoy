#ifndef _Carte_H_
#define _Carte_H_



class Carte { }



#endif // _Carte_H_
