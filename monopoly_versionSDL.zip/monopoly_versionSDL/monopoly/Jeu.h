#ifndef _JEU_H_
#define _JEU_H_

#include "Joueur.h"
#include "Plateau.h"

class Jeu {

private:
    Plateau plat;
    int nbJ; //pour l'instant constant � deux joueur
    Joueur* tabJ[2];

public :
    Jeu();
    int lancerDeDe();
    void unTour();
    void deplacerJoueur(int de);
    void affichageRegleDuJeu();
    void acheterCase();
};

#endif // _JEU_H_
