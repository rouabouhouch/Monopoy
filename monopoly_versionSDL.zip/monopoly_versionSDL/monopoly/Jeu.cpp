#include <ctime>
#include "Jeu.h"

Jeu::Jeu() {
    nbJ = 2;
    tabJ[0] = new Joueur(plat.getCase(1));
    tabJ[1] = new Joueur(plat.getCase(1));
}

int Jeu::lancerDeDe()
{
    srand(time(0));
    int dice =(rand()%6 +1);
    return dice;
}

void Jeu::unTour() {
    cout<<"Plateau avant tour de jeu : "<<endl<<endl;
    plat.afficherPlateau(tabJ[0]->getJoueurPosition());
    cout<<endl;
    int lance = lancerDeDe();
    cout<<"Lancer de d� : "<<lance<<endl;
    deplacerJoueur(lance);
    cout<<"Plateau apr�s le tour de jeu : "<<endl<<endl;
    plat.afficherPlateau(tabJ[0]->getJoueurPosition());
    acheterCase(); //action de la case

}

void Jeu::deplacerJoueur(int de) {
        //changer la case position du joueur
    tabJ[0]->setJoueurPosition(plat.getCase(tabJ[0]->getJoueurPosition()->getPositionDansPlateau() /*ancienne place + lanc� de d�*/ + de));
    //il faut v�rifier si il a fini le tour du plateau

}

void Jeu::affichageRegleDuJeu() {
    cout << "Les r�gles du jeu ne sont pas encore disponnible"<<endl;
}

void Jeu::acheterCase() {
    switch (tabJ[0]->getJoueurPosition()->getTypeCase()) {
        case 0 : //case d�part
            //rien � faire
            break;
        case 1 : //case achetable

                //si la case appartient � personne il peut l'acheter
            if(tabJ[0]->getJoueurPosition()->getPossederPar()== NULL) {

                //si le joueur � plus d'argent que co�t la case alors il peut l'acheter
                if(tabJ[0]->getArgent()> tabJ[0]->getJoueurPosition()->getPrix()) {
                    //peut acheter la case
                    cout<< "Voulez vous acheter la case : <<"<<tabJ[0]->getJoueurPosition()->getNomC() <<">> pour : "<<tabJ[0]->getJoueurPosition()->getPrix()<<"M"<<endl;
                    cout<<"Votre argent : "<< tabJ[0]->getArgent()<<"M";
                    cout<<endl<<endl;
                    cout<<"Sasir o (pour oui) ou n (pour non) : ";
                    //---------------interaction HIM
                    char reponse;
                    cin>> reponse;
                    //------------------------------
                    if(reponse=='o'){ //il faut soustraire le prix de la case
                        tabJ[0]->takeMoney(tabJ[0]->getJoueurPosition()->getPrix());
                        cout<<endl;
                        cout<<"Vous avez bien achet� la case. Il vous reste : "<< tabJ[0]->getArgent()<<"M"<<endl;
                    } //sinon il n'y a rien � faire

                } else {
                    //peut pas acheter la case
                    cout << "Vous n'avez pas assez d'argent pour acheter la case"<<endl;
                }

            } else { //sinon il doit payer le joueur qui la poss�de

            }

            break ;
        case 2 : //gare

                //si la case appartient � personne il peut l'acheter
            if(tabJ[0]->getJoueurPosition()->getPossederPar()== NULL) {

                    //si le joueur � plus d'argent que co�t la case alors il peut l'acheter
                if(tabJ[0]->getArgent()> tabJ[0]->getJoueurPosition()->getPrix()) {
                    //peut acheter la case
                } else {
                    //peut pas acheter la case
                    cout << "Vous n'avez pas assez d'argent pour acheter la case"<<endl;
                }

            } else { //sinon il doit payer le joueur qui la poss�de en fonction du nombre de gare poss�d�

            }

            break;
        case 3 : //tirer une carte

            break;
        case 4 : //aller en prison
            deplacerJoueur(0 /* position de la case prison */);

            break;
        case 5 : //case prison

            break;
        case 6 : // communaut�


            break;
        case 7 : //case � payer (ex : imp�t)
            cout<<"Aie, vous �tes sur la case : "<<tabJ[0]->getJoueurPosition()->getNomC()<<endl;
            cout<<"Vous devez payer : "<<tabJ[0]->getJoueurPosition()->getPrix()<<"M"<<endl;
            tabJ[0]->takeMoney(tabJ[0]->getJoueurPosition()->getPrix());
            cout<<"Argent apr�s impot : "<<tabJ[0]->getJoueurPosition()->getPrix()<<"M"<<endl;

            break;
    }

}

