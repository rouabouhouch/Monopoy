#ifndef SDL2_H_INCLUDED
#define SDL2_H_INCLUDED
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <string>
#include "sdl_case.h"
#include <SDL2/SDL_mixer.h>

struct player
{
    std::string name;
    int money;
};
struct hotel
{
    int pos_x;
    int pos_y;
    int num;

};

class sdlJeu {


  private :
    bool mMouseFocus;
    bool mKeyboardFocus;
    sdl_case sc;
    player p1;
    player p2;
    SDL_Event event;
    bool running2=true;

    SDL_Window * window;
    SDL_Window *mWindow=NULL;
    TTF_Font *font;
    TTF_Font *font2;
    const Uint8 *keystates=SDL_GetKeyboardState(NULL);
    bool type_player1=true;
    SDL_Renderer * renderer;
    SDL_Renderer *mrenderer;
    SDL_Color black = {0,0,0};
    SDL_Color Red= {255,0,0};
    SDL_Color Green={124,255,0};
    int texW = 0;
    int texH = 0;
    int texW2 =0;
    int texH2=0;
    int messagew=0;
    int messageh=0;
    SDL_Surface *textsurface;
    bool rendertext1 = false;
    bool rendertext2=false;
    int screen_width= 1100;
    int screen_width2=500;
    int screen_height=700;
    int screen_height2=200;
    int WindowID;
    SDL_Texture *plateau;
    SDL_Texture *dice;
    SDL_Texture *player1;
    SDL_Texture * player2;
    SDL_Texture *joueur1;
    SDL_Texture *joueur2;
    SDL_Texture *Background;
    SDL_Texture *background2;
    SDL_Texture *monopolyguy;
    SDL_Texture * mytexture;
    SDL_Texture *player1name;
    SDL_Texture *player2name;
    SDL_Texture *message_window2;
    SDL_Texture *yes;
    SDL_Texture *redhotel [40];
    SDL_Texture *greenhotel [40];
    SDL_Texture *money1;
    SDL_Texture *money2;
    SDL_Texture *start;
    SDL_Texture *player_win;
    SDL_Texture *victory;
    SDL_Texture *turn;








    int moneyw1, moneyh1, moneyw2,moneyh2;
    int dice_test=1;
    int dice_x=((screen_width-100)/2)+10;
    int dice_y=((screen_height-100)/2)+125;
    int dice_width=100;
    int dice_height=100;
    int positionx_joueur1=screen_width-100 ;
    int positiony_joueur1=screen_height-60 ;
    int positionx_joueur2=screen_width-70;
    int positiony_joueur2=screen_height-60;
    int case_joueur1=1;
    int case_joueur2=1;
    bool player_1 = true;
    bool player1_wins=false;
    bool player2_wins=false;
    std::string window_message;
    bool case_achetable=false;
    bool acheter_joueur1=false;
    bool acheter_joueur2=false;
    bool player1_gagne=false;
    bool player2_gagne=false;
    int yes_x=(screen_width2/3)-20;
    int yes_y=screen_height2/3;
    int yes_w=100;
    int yes_h=100;
    int no_w=(screen_width2/2)+20;
    int position_hotel_vert;
    int position_hotel_rougey;
    int position_hotel_rouge;
    int i =0;
    int z=0;
    hotel red [40];
    hotel green[40];
    int a =0;
    int b=0;
    int dice2;
    bool sent_to_jail=false;
    bool sent_to_jail2=false;
    int win_w;
    int win_h;


public :

    ~sdlJeu (); // memory cleanup
    void  initialisaion (); // initialise sdl
    void create_window ( int mSCREEN_WIDTH, int mSCREEN_HEIGHT);
    void sdl_dice (int & diceOne);
    void draw_dice ();
    void sdl_exit_error (const char *message); // gestion erreur
    SDL_Texture  * create_text_texture (const char *text , SDL_Color textColor ,int & textw_text ,int & texth_text);
    SDL_Texture  * create_text_texture2 (const char *text , SDL_Color textColor ,int & textw_text ,int & texth_text);

    SDL_Texture * initialize_texture_from_file(const char* file_name, SDL_Renderer *renderer);

    void SDL_drawing (
                        int imagex_source , int imagey_source,
                        int image_w_source, int image_h_source,
                        int imagex , int imagey ,
                        int image_width , int image_height , SDL_Texture *texture
                      );
     void SDL_drawing2 (
                        int imagex_source , int imagey_source,
                        int image_w_source, int image_h_source,
                        int imagex , int imagey ,
                        int image_width , int image_height , SDL_Texture *texture,int x
                      );
    void set_player(int i);
    void fill_hotel_position(hotel tab[40],int x, int y ,int w,int &m , int &check);
    void move_player(int &case_test);
    void sdl_boucle ();
    void sdl_jouer ();
    void handle_input(std:: string &character_name,bool &renderText);
    SDL_Texture *load_input (std::string & player_name , bool &input , int x1 ,int x2);
    void create_popup_window(int type_case, int num_case);
};


#endif // SDL2_H_INCLUDED
