#ifndef SDL_CASE_H_INCLUDED
#define SDL_CASE_H_INCLUDED
#include <string>
struct casesdl
{
    int x;
    int y;
    int w;
    int h;
    int price;
    std::string nom_case;
    int case_type;
    int posseder_par_joueur;
};
class sdl_case
{
private:

    struct casesdl t[40];

public:
    sdl_case ();
    void set_case (int num_case, int x_case ,int y_case , int w_case, int h_case , int case_price1 , int case_type1,
                   std::string name_case1);
    casesdl get_case (int case_num);
    void set_possederpar(int a , int num_case);

};


#endif // SDL_CASE_H_INCLUDED
