#include "sdl_case.h"

sdl_case::sdl_case()
{
set_case(0,942 ,600,1085,690,0,0,"case de depart");
set_case(1,851,600,942,690,60,1,"Avenue De Medi");
set_case(2,770,600,851,690,0,6,"commuunity chest");
set_case(3,683,600,770,690,60,1,"Avenue Orientale");
set_case(4,595,600,683,690,60,2,"Gare 1");
set_case(5,510,600,595,690,60,2,"Gare 2");
set_case(6,420,600,510,690,100,1,"Rue Monstad");
set_case(7,334,600,420,690,0,3,"Case Chance");
set_case(8,246,600,334,690,100,1,"Rue Mozart");
set_case(9,158,600,246,690,100,1,"Rue Philips");
set_case(10,15,600,158,690,0,5,"Prison");
set_case(11,15,544,158,600,120,1,"Rue Mina");
set_case(12,15,490,158,544,100,7,"Electric Company");
set_case(13,15,430,158,490,120,1,"Avenue Jean");
set_case(14,15,378,158,430,120,1,"Avenue Victor");
set_case(15,15,322,158,378,200,2,"Gare 3");
set_case(16,15,267,158,322,140,1,"Rue Nova");
set_case(17,15,210,158,267,0,6,"Community");
set_case(18,15,155,158,210,140,1,"Avenue Maurice");
set_case(19,15,100,158,155,140,1,"Rue Albert");
set_case(20,15,10,158,100,0,8,"Free Parking");
set_case(21,158,10,246,100,160,1,"Park Des Mimis");
set_case(22,246,10,332,100,0,3,"chance");
set_case(23,332,10,420,100,160,1,"Avenue Camus");
set_case(24,420,10,507,100,160,1,"Avenue du Parc");
set_case(25,507,10,594,100,200,2,"Gare 4");
set_case(26,594,10,682,100,180,1,"Avenue Lili");
set_case(27,682,10,769,100,180,1,"Avenue Sortie");
set_case(28,769,10,857,100,100,7,"Facture Eau");
set_case(29,857,10,942,100,180,1,"Campus Cruiser");
set_case(30,942,10,1080,100,0,4,"Aller En Prison");
set_case(31,942,100,1080,158,200,1,"Avenue Luxe");
set_case(32,943,157,1080,213,200,1,"Knight's Bench");
set_case(33,943,213,1080,270,0,6,"community");
set_case(34,943,270,1080,325,200,1,"Avenue Bernard");
set_case(35,943,325,1080,380,200,2,"Gare 5");
set_case(36,943,380,1080,435,0,3,"chance");
set_case(37,943,435,1080,493,300,1,"Avenue Lux");
set_case(38,943,493,1080,546,400,2,"Gare 6");
set_case(39,943,546,1080,600,300,1,"Avenue Finale");



}
void sdl_case::set_case(int num_case, int x_case ,int y_case , int w_case, int h_case ,int case_price1,
                        int case_type1 , std::string name_case1)
{
    t[num_case].x = x_case;
    t[num_case].y = y_case;
    t[num_case].w = w_case;
    t[num_case].h = h_case;
    t[num_case].case_type=case_type1;
    t[num_case].nom_case=name_case1;
    t[num_case].price= case_price1;
    t[num_case].posseder_par_joueur=NULL;

}
casesdl sdl_case::get_case(int case_num)
{
    return t[case_num];
}
void sdl_case::set_possederpar(int a, int num_case)
{
     t[num_case].posseder_par_joueur=a;
}
