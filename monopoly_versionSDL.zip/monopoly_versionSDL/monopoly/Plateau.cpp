#include "Plateau.h"

Plateau::Plateau() {
    taille = 10;
    tab[0] = new Case(1, "D�part",0,0,0);
    tab[1] = new Case(2, "Boulevard de Belleville",1,60,4);
    tab[2] = new Case(3, "Caisse de communaut�",7,20,20);
    tab[3] = new Case(4, "Rue Lecourbe",1,60,4);
    tab[4] = new Case(5, "Imp�t sur le revenu",7,200,200);
    tab[5] = new Case(6, "Gare Montparnasse",2,200,25);
    tab[6] = new Case(7, "Rue de vaugirard",1,100,6);
    tab[7] = new Case(8, "Chance",3,0,0);
    tab[8] = new Case(9, "Rue de courcelles",1,100,6);
    tab[9] = new Case(10, "Avenue de la r�publique",1,100,6);
}

Plateau::~Plateau() {

}

int Plateau::getTaille() {
    return taille;
}


void Plateau::afficherPlateau(Case* caseJoueur) {

    for(int i = 0; i<taille; i++) {
        cout<<"------------------------------------"<<endl;
        cout<<tab[i]->getNomC()<<endl;
        cout<<"Prix : " << tab[i]->getPrix()<<endl;
        if(tab[i]==caseJoueur){ //si le joueur est sur la case
            cout<<"Joueur 1 ! "<<endl;
        }
        cout<<"------------------------------------"<<endl<<endl<<endl;
    }

}

Case* Plateau::getCase(int indice) {
    bool stop = false;
    int i = 0;
    while(!stop){
        if(tab[i]->getPositionDansPlateau() == indice) {
            stop = true;
            return tab[i];
        }
        i++;
    }
    return 0;
}
