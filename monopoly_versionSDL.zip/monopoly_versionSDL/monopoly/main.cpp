
#include <ctime>
#include "sdl2jeu.h"

int main (int argc, char** argv) {
	sdlJeu sd;
	sd.sdl_jouer();
}
