#ifndef _JOUEUR_H_
#define _JOUEUR_H_
#include <string>
#include<cstring>
#include <vector>

using namespace std;

class Case;

class Joueur {

private:
	//string gamePieceName;
	string nomJ;
	Case* joueurPosition;
	int argent;
	 vector<Case> casePosseder;

public:
	//constructors
	Joueur(string nom, Case* depart);
    Joueur(Case* depart);

	//functions to set
	void setNom(string inputName);
	//void setGamePieceName(string inputPieceName);
	void setArgent(int arg);
    void setCasePossede(Case* cas);
    void setJoueurPosition(Case* cas);

	//functions to get
	string getNom();
	string getgamePieceName;
	int getArgent();
	string getCassePossede();
    Case* getJoueurPosition();

	//money functions
	void giveMoney(int amount);
	void takeMoney(int amount);
    //void movePlayer(int number);   if we needed at the end

    };

 #endif // _JOUEUR_H_
